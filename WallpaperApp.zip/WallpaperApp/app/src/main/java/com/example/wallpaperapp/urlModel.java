package com.example.wallpaperapp;

public class urlModel {

    private String portrait;

    public String getPortrait() {
        return portrait;
    }

    public void setPortrait(String portrait) {
        this.portrait = portrait;
    }

    public urlModel(String portrait) {
        this.portrait = portrait;
    }
}
